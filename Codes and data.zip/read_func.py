# functions to read data
import numpy as np
import ast
import random

# read the network
def read_sioux(path, filename):
    file_object = open(path + filename, 'r', encoding='UTF-8')
    lines = file_object.readlines()
    edges=[]
    cost=[]
    try:
        for line in lines:
            dataline = line.split()
            for i in dataline:
                edges.append(ast.literal_eval(dataline[0]+","+dataline[1]))
                cost.append(ast.literal_eval(dataline[2]))
                break
    finally:
        file_object.close()
    return edges, cost

# read profit text file for TOARP-TP
def read_profits(path,filename):
    file_object = open(path + filename, 'r', encoding='UTF-8')
    lines = file_object.readlines()
    p_edges = []
    profit_multi = []
    try:
        for line in lines:
            dataline = line.split('\t')
            for i in dataline:

                p_edges.append(ast.literal_eval(dataline[0]))
                profit_multi.append(ast.literal_eval(dataline[2]))
                break
    finally:
        file_object.close()
    return p_edges, profit_multi

# read profit text file for TOARP
def read_profits_TOARP(path,filename):
    file_object = open(path + filename, 'r', encoding='UTF-8')
    lines = file_object.readlines()
    p_edges = []
    profit_multi = []
    try:
        for line in lines:
            dataline = line.split('\t')
            for i in dataline:
                p_edges.append(ast.literal_eval(dataline[0]))
                profit_multi.append(ast.literal_eval(dataline[2]))
                break
    finally:
        file_object.close()
    profits=[]
    for item in profit_multi:
        li=np.array(item)
        profits.append(li.mean())
    return p_edges, profits

