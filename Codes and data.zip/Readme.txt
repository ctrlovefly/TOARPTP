1. Folder 'Data' contains two subfolders 'Sioux' and 'Wuhan'. 
The data files in 'Sioux' were used in the numerical experiments of Section 4.
The data files in 'Wuhan' were used in the case study of Section 5.

2. In the code file named 'Gurobi_reformulated TOARP.py', the reformulated TOARP is modeled and solved based on python extension module 'gurobipy'.
In the code file named 'Gurobi_TOARP-ST.py', the TOARP-ST is modeled and solved based on python extension module 'gurobipy'.
The module 'gurobipy' can be found in https://www.gurobi.com/documentation/9.1/quickstart_mac/cs_python.html.

The code file named 'ILS_TOARP-ST.py' contains the source codes of the ILS algorithm for the TOARP-TP. 

The files named 'ODmatrix.py' and 'read_func.py' are custom extension modules called in the other three code files.





