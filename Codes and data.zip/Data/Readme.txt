1. The files named 'network.txt' containing network information have the following format:
<u1>	<u2>	<c>
<u2>	<u1>	<c>
.
.
.

Each line 
<u1>	<u2>	<c>
indicates that the arc from node u1 to node u2 has a cost <c> to traverse it.

2. The files in the folder 'multiperiod profits' contain the profit values. They have the following format:
(<u1>,<u2>)	profit	[<p1>, <p2>, <p3>,...]
.
.
.

Each line 
(<u1>,<u2>)	profit	[<p1>, <p2>, <p3>,...]
indicates that the profitable arc (<u1>,<u2>) has a list of profit values [<p1>, <p2>, <p3>,...]
where pn is the profit collected when the arc is traversed in the subperiod n.

3. The files in the folder named 'SHP' were processed in ArcGIS and used for spatiotemporal demand representation in Section 5.

 
