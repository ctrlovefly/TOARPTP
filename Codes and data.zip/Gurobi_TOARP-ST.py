# python interpreter: python3.7
# Solve the TOARP-ST problem

import gurobipy as gp
from gurobipy import GRB
from collections import defaultdict
import ODmatrix
import os
import read_func

interval_num = 6            # number of subperiods

def model_solve(path,filename,path1,filename1,outpath):
    """
    path:path_instance
    filename:filename_instance
    path1:path_multiprofit
    filename1:filename_multiprofit
    outpath:write in the txt of the path
    """
    # read data
    edges,cost=read_func.read_sioux(path,filename)
    p_edges,profit_multi=read_func.read_profits(path1,filename1)
    num_vertex=24
    vehicle = range(num_vehicle)
    step = interval_span / interval_num
    intervals=[]
    for inter in range(interval_num):
        left = inter*step
        right = (inter+1)*step
        intervals.append((left,right))
    dist = defaultdict(list)
    for i, item in enumerate(edges):
        dist[item] = cost[i]
    demand = defaultdict(list)
    for p, item in enumerate(p_edges):
        for q,thin in enumerate(intervals):
            demand[item[0],item[1],thin[0],thin[1]] = profit_multi[p][q]
    _, cost_enum = gp.multidict(dist)
    _, profit_enum = gp.multidict(demand)

    # some parameters
    O = [(9,9)]     # depot
    M = 1000        # big M

    # OD matrix
    OD_cal_list=[]
    for i,j in cost_enum:
        OD_cal_list.append((i,j,cost_enum[(i,j)]))
    OD=ODmatrix.OD_cal(OD_cal_list,num_vertex)
    T_large=450     # a large time for bounds

    # Gurobi model
    m = gp.Model("TOARP-ST")

    # Variables
    w = m.addVars(p_edges,intervals,vtype=GRB.BINARY,name="w")
    yijk = m.addVars(p_edges, vehicle, vtype=GRB.BINARY, name="yijk")
    bij = m.addVars(p_edges,lb=0.0, vtype=GRB.CONTINUOUS, name="bij")
    union_p_edges=list(set(p_edges).union(set(O)))
    z = m.addVars(union_p_edges, union_p_edges, vehicle, vtype=GRB.BINARY, name="z")
    y1=m.addVars(p_edges,intervals,vtype=GRB.BINARY,name="y1")
    y2=m.addVars(p_edges,intervals,vtype=GRB.BINARY,name="y2")
    y3=m.addVars(p_edges,intervals,vtype=GRB.BINARY,name="y3")

    # Objective
    obj = gp.quicksum(profit_enum[e1, e2, u1, u2] * yijk[e1, e2, k] * w[e1,e2,u1,u2] for e1, e2 in p_edges for k in vehicle for u1, u2 in intervals)
    m.setObjective(obj, GRB.MAXIMIZE)

    # Constraints
    m.addConstrs((gp.quicksum(z[O[0][0],O[0][1],i,j,k] for i,j in p_edges)==1 for k in vehicle), "depot_left")

    m.addConstrs((gp.quicksum(z[i,j,O[0][0],O[0][1],k] for i,j in p_edges)==1 for k in vehicle), "depot_right")

    m.addConstrs((gp.quicksum(yijk[i,j,k] for k in vehicle)+gp.quicksum(yijk[j,i,k] for k in vehicle)<=1 for i,j in p_edges if (j,i) in p_edges),"only_once")

    m.addConstrs((gp.quicksum(z[i,j,i1,j1,k] for i1,j1 in union_p_edges)==gp.quicksum(z[i2,j2,i,j,k] for i2,j2 in union_p_edges) for k in vehicle for i,j in p_edges),"vrp_flow_conservation")

    m.addConstrs((gp.quicksum(z[i2,j2,i,j,k] for i2,j2 in union_p_edges)==yijk[i,j,k] for k in vehicle for i,j in p_edges),"relation between z and yijk")

    m.addConstrs((bij[i1,j1]+M*(1-gp.quicksum(z[i,j,i1,j1,k] for k in vehicle))>=bij[i,j]+cost_enum[i,j]+OD[j-1][i1-1] for i,j in p_edges for i1,j1 in p_edges),"start time ctrl")

    m.addConstrs((bij[i1,j1]-M*(1-gp.quicksum(z[i,j,i1,j1,k] for k in vehicle))<=bij[i,j]+cost_enum[i,j]+OD[j-1][i1-1] for i,j in p_edges for i1,j1 in p_edges),"start time ctrl2")

    m.addConstrs((gp.quicksum(OD[j-1][i1-1]*z[i,j,i1,j1,k] for i,j in union_p_edges for i1,j1 in union_p_edges)+gp.quicksum(cost_enum[i,j]*yijk[i,j,k]for i,j in p_edges)<=Tmax for k in vehicle),"totel time")

    m.addConstrs((bij[i,j]+M*(1-z[O[0][0],O[0][1],i,j,k])>=OD[O[0][0]-1][i-1] for i,j in p_edges for k in vehicle),"start time ctrl3")

    m.addConstrs((bij[i,j]-M*(1-z[O[0][0],O[0][1],i,j,k])<=OD[O[0][0]-1][i-1] for i,j in p_edges for k in vehicle),"start time ctrl4")

    m.addConstrs((bij[i,j]+cost_enum[i,j]+OD[j-1][O[0][0]-1]<=Tmax+M*(1-yijk[i,j,k]) for i,j in p_edges for k in vehicle),"start time ctrl5")

    m.addConstrs((gp.quicksum(w[i,j,u,u1] for u,u1 in intervals)<=1 for i,j in p_edges),"w ctrl")

    m.addConstrs((y1[i,j,u,u1]+y2[i,j,u,u1]+y3[i,j,u,u1]==1 for i,j in p_edges for u,u1 in intervals),"linear bij1")

    m.addConstrs((w[i,j,u,u1]==y2[i,j,u,u1] for i,j in p_edges for u,u1 in intervals),"linear bij2")

    m.addConstrs((bij[i,j]<=u*y1[i,j,u,u1]+u1*y2[i,j,u,u1]+M*y3[i,j,u,u1] for i,j in p_edges for u,u1 in intervals),"linear bij3")

    m.addConstrs((bij[i,j]>=u*y2[i,j,u,u1]+u1*y3[i,j,u,u1] for i,j in p_edges for u,u1 in intervals),"linear bij4")

    m.addConstrs((bij[i,j]+M*gp.quicksum(yijk[i,j,k] for k in vehicle)>=T_large for i,j in p_edges),"relation between yijk and bij")

    m.addConstrs((bij[i,j]-M*gp.quicksum(yijk[i,j,k] for k in vehicle)<=T_large for i,j in p_edges),"relation between yijk and bij2")

    # function to save the solution
    def write_in():
        pa = outpath +str(num_vehicle)+"_"+str(Tmax)+"_"+str(O[0][0])+"_"+ filename1
        with open(pa, 'w') as file_object:
            file_object.write(str(m.Runtime) + "\n")
            file_object.write(str(m.objVal) + "\n")
        pa2=outpath+"allin.txt"
        with open(pa2, 'w') as file_object1:
            file_object1.write(str(m.Runtime) + "\n")
            file_object1.write(str(m.objVal) + "\n")

    # function to print the solution
    def printSolution():
        # if m.status == GRB.OPTIMAL:
        print('\n目标函数: %g' % m.objVal)
        print('\nyijk收益路段:')
        yijkx = m.getAttr('x', yijk)
        for k in vehicle:
            for i,j in p_edges:
                if yijk[i,j,k].x == 1:
                    print('%d %d %d %g' % (i,j,k,yijkx[i,j,k]))
        print('\nz车辆路线:')
        for k in vehicle:
            print('\n第%d个车辆:'% k)
            for i,j in union_p_edges:
                for i1,i2 in union_p_edges:
                    if z[i,j,i1,i2,k].x==1:
                        print('[%d,%d,%d,%d,%d],' % (i,j,i1,i2,k))
        print('\n求解时间：%g' % m.Runtime)
        bijx = m.getAttr('x', bij)
        for i,j in p_edges:
            if bij[i,j].x>0 and bij[i,j].x<400:
                print('%d %d %g' % (i,j,bijx[i,j]))

    # solving time limit
    m.Params.timeLimit=10000

    # solve the model
    m.optimize()

    # save or print results
    write_in()
    printSolution()

def file_name(file_dir):
    L=[]
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            if os.path.splitext(file)[1] == '.txt':  # 想要保存的文件格式
                L.append(file)
    return L

if __name__ == '__main__':
    global num_vehicle,interval_span,Tmax
    time_list=[30]
    instance_dir = r"C:\Users\89245\Desktop\DATA210331\\"                               # file path of the network
    instance="network.txt"                                                              # file name of the network
    instance_profit_dir=r'C:\Users\89245\Desktop\210407TEST\sioux_6\\'                  # file path of the profits
    result_dir = r'C:\Users\89245\Desktop\210407TEST\guModel_TOTP\hard_res_rerandom\\'  # output path
    instance_list = file_name(instance_profit_dir)                                      # names of the profit files
    for vehicle in range(2, 6):                                                         # batch processing
        num_vehicle = vehicle
        for time in time_list:
            interval_span = time
            Tmax = time
            for instance_profit in instance_list:
                if instance_profit=="sioux_20_6.txt":
                    model_solve(instance_dir, instance, instance_profit_dir, instance_profit, result_dir)   # solve the TOARP-TP
    print("finished!")



