# ILS for TOARP-TP
from collections import defaultdict
import random
import copy
import math
import time
import ODmatrix
import os
import read_func

depot = (9, 9)                                          # dummy arc
p_Edges, OD, dist, profits = [], [], [], []             # profit edges, OD matrix, edge length (cost), edge profit
bidirect, profits_p_Edges, profits_time = {}, {}, {}
arc_nearcandi = []
start_nearcandi = []
num_vertex = 24                                         # number of the network nodes
cube_slices = 6                                         # number of the subperiods

def load_INS(path, filename, path1, filename1):
    # read the instance
    edges, cost = read_func.read_sioux(path, filename)
    p_Edges, profit_multi = read_func.read_profits(path1, filename1)

    # edge cost
    dist = defaultdict(list)
    for index, item in enumerate(edges):
        dist[(item[0], item[1])] = cost[index]

    # opposite arcs of arcs
    distinct_Edges = copy.deepcopy(edges)
    for i in range(len(edges)):
        for j in range(i):
            if edges[i][0] == edges[j][1] and edges[i][1] == edges[j][0]:
                distinct_Edges.remove(edges[i])
    bidirect = defaultdict(list)
    for i in distinct_Edges:
        bidirect[(i[0], i[1])] = tuple([i[1], i[0]])
        bidirect[(i[1], i[0])] = tuple([i[0], i[1]])

    # OD matrix
    Edges = [(item[0], item[1], cost[index]) for index, item in enumerate(edges)]
    OD = ODmatrix.OD_cal(Edges, num_vertex)
    OD_change = []
    for i in range(len(OD) + 1):
        if i == 0:
            OD_change.append([0 for j in range(len(OD) + 1)])
        else:
            OD_change.append([0] + OD[i - 1][:])
    OD = OD_change

    # multiperiod profits
    profit_multi_T = [[profit_multi[i][j] for i in range(len(profit_multi))] for j in range(len(profit_multi[0]))]
    profits = profit_multi_T
    profits_p_Edges = defaultdict(list)
    index = 0
    for s, e in p_Edges:
        profits_p_Edges[(s, e)] = index
        profits_p_Edges[(e, s)]=index
        index = index + 1

    # subperiods
    time_index = 0
    profits_time = defaultdict(list)
    step = cube_max / cube_slices
    for i in range(cube_slices):
        left = i * step
        right = (i + 1) * step
        profits_time[(left, right)] = time_index
        time_index = time_index + 1
    return p_Edges, bidirect, OD, dist, profits, profits_p_Edges,profits_time

# calculate the flight time of an UAV
def time_calculate(route):
    one_path_length = []
    for no in range(len(route)):
        if no == 0:
            one_path_length.append(OD[depot[1]][route[no][0]] + dist[route[no]])
        else:
            one_path_length.append(OD[route[no - 1][1]][route[no][0]] + dist[route[no]])
    if len(route) !=0:
        one_path_length.append(OD[route[len(route) - 1][1]][depot[0]])
    sum_length = sum(one_path_length)
    return sum_length

# 获得二维列表中某个值的下标 subscript of an element in a 2D list
def subscript_2D(value, list_2D):
    sub = []
    for v in list_2D:
        if value in v:
            sub = [list_2D.index(v), v.index(value)]
    return sub

# Function 1 related to regret value
def min_k_pos_calculate(list_ci, cii):
    dict_ci = defaultdict(list)
    cii_flag = 0
    for ci in list_ci:
        ci_flat = [i for item in ci for i in item]
        sub = subscript_2D(min(ci_flat), ci)
        dict_ci[cii[cii_flag]] = sub
        cii_flag += 1
    return dict_ci

# Function 2 related to regret value
def regret_value_calculate(candidate_list, routes):
    list_ci = []
    for i in candidate_list:
        list_k = []
        for k in routes:
            list_fik = []
            for pos in range(len(k) + 1):
                k_temp = copy.deepcopy(k)
                k_temp.insert(pos, i)
                if time_calculate(k_temp) <= Tmax:
                    if fitness_calculate([k_temp])-fitness_calculate([k])==0:
                        list_fik.append(999999)
                    else:
                        list_fik.append((fitness_calculate([k_temp])-fitness_calculate([k])))
                else:
                    list_fik.append(999999)
            list_k.append(list_fik)
        list_ci.append(list_k)
    return list_ci

# Function 3 related to regret value
def delta_ci_calculate(list_ci):
    delta_ci = []
    for i in list_ci:
        list_k = []
        for j in range(len(i)):
            for k in range(len(i[j])):
                list_k.append(i[j][k])
        list_k.sort()
        delta_ci.append(list_k[1] - list_k[0])
    return delta_ci

# probability based selection
def probability_select(candi_list, preference_list):
    r = random.random()
    c = 0
    total = sum(preference_list)
    probab_list = []
    for (index, item) in enumerate(preference_list):
        pr=float(item) / float(total)
        probab_list.append(pr)
    for (index, item) in enumerate(probab_list):
        c = c + item
        if r <= c:
            return candi_list[index]

###############################################################
# perturbation operator 3：reverse arc
###############################################################
def bidirect_insert(i, routes):
    reRoutes = copy.deepcopy(routes)
    x, y = subscript_2D(i, routes)
    if len(reRoutes[x]) >= 2:
        reRoutes[x].pop(y)
    else:
        return routes
    if bidirect[i] in p_Edges:
        add = bidirect[i]
    else:
        return routes
    list_ci = regret_value_calculate([add], reRoutes)
    dict_ci = min_k_pos_calculate(list_ci, [add])
    min_k = dict_ci[add][0]
    min_pos = dict_ci[add][1]
    reRoutes[min_k].insert(min_pos, add)

    if time_calculate(reRoutes[min_k]) <= Tmax:
        return reRoutes
    else:
        return routes

###############################################################
# initial solution generation
###############################################################
def initialize():
    empty_routes = [[] for x in range(num_vehicles)]
    max_not_insert = 0
    candi = []
    nearange = start_nearcandi[depot]
    for item in nearange:
        candi.append((item[0], item[1]))
    for ci in candi:
        k = random.randint(0, len(empty_routes) - 1)
        empty_routes[k].append(ci)
        if time_calculate(empty_routes[k]) <= Tmax:
                candi.remove(ci)
                f=0
                for i in empty_routes:
                    if i==[]:
                        f+=1
                if f<1:
                    break
        else:
            empty_routes[k].remove(ci)
    while (max_not_insert < 100):
        list_ci = regret_value_calculate(candi, empty_routes)
        delta_ci = delta_ci_calculate(list_ci)
        preference_value = delta_ci
        dict_pos = min_k_pos_calculate(list_ci, candi)

        if sum(preference_value) == 0:
            break
        add = probability_select(candi, preference_value)
        x, y = dict_pos[add]
        if bidirect[add] not in [i for j in empty_routes for i in j] and add not in [i for j in empty_routes for i in
                                                                                     j]:
            empty_routes[x].insert(y, add)
            if time_calculate(empty_routes[x]) <= Tmax:
                candi.remove(add)
            else:
                empty_routes[x].remove(add)
        else:
            max_not_insert += 1
    return empty_routes


def add_dummynode(routes):
    routes_copy = copy.deepcopy(routes)
    for item in routes_copy:
        item.append(depot)
    return routes_copy

###############################################################
# judge the relative position of two arcs in a solution 
###############################################################
def judge_relative_pos(i, c, routes):
    for r in routes:
        if i in r and c in r:
            return 0
    if c in [d for item in routes for d in item]:
        return 1
    if c not in [d for item in routes for d in item]:
        return 2

###############################################################
# LS operator 1
###############################################################
def reversePath(path):
    rePath = copy.deepcopy(path)
    rePath=list(reversed(path))
    return rePath

def opt2(i, c, route):
    reRoute = copy.deepcopy(route)
    if abs(route.index(i) - route.index(c)) > 0:
        if route.index(i) > route.index(c):#
            rePath = reversePath(route[route.index(c):route.index(i) + 1])
            reRoute[route.index(c):route.index(i) + 1] = rePath
        else:
            rePath = reversePath(route[route.index(i):route.index(c) + 1])
            reRoute[route.index(i):route.index(c) + 1] = rePath
        if time_calculate(reRoute) < time_calculate(route):
            return reRoute
        else:
            return route
    else:
        return route

###############################################################
# LS operator 2-1
###############################################################
def exchange_move(i, c, routes_cons):
    routes = copy.deepcopy(routes_cons)
    k1, p1 = subscript_2D(i, routes)
    k2, p2 = subscript_2D(c, routes)
    pos1_in_path1 = p1
    pos2_in_path2 = p2
    routes[k1] = routes_cons[k1][:pos1_in_path1] + routes_cons[k2][pos2_in_path2:pos2_in_path2 + 1] + routes_cons[k1][
                                                                                                      pos1_in_path1 + 1:]
    routes[k2] = routes_cons[k2][:pos2_in_path2] + routes_cons[k1][pos1_in_path1:pos1_in_path1 + 1] + routes_cons[k2][
                                                                                                      pos2_in_path2 + 1:]
    if time_calculate(routes[k1]) < Tmax and time_calculate(routes[k1])+time_calculate(routes[k2])<time_calculate(routes_cons[k1]) +time_calculate(routes_cons[k2]) and time_calculate(routes[k2]) < Tmax:
        return routes,time_calculate(routes_cons[k1]) +time_calculate(routes_cons[k2])-(time_calculate(routes[k1])+time_calculate(routes[k2]))
    else:
        return routes_cons,0

###############################################################
# LS operator 2-2
###############################################################
def relocate_move(i, routes_cons):
    routes = copy.deepcopy(routes_cons)
    for re in range(len(i)):
        a, b = subscript_2D(i[re], routes)
        if len(routes[a]) >= 2:
            del routes[a][b]
        else:
            return routes_cons,0
    ####
    # regret value for removed_arcs
    ####
    list_ci = regret_value_calculate(i, routes)
    delta_ci = delta_ci_calculate(list_ci)
    ci_sort = []
    for index, item in enumerate(delta_ci):
        ci_sort.append((index, item))
    ci_sort_after = sorted(ci_sort, key=lambda x: x[1], reverse=True)
    random.shuffle(ci_sort_after)
    dict_ci = min_k_pos_calculate(list_ci, i)
    for c in ci_sort_after:
        min_k, min_pos = dict_ci[i[c[0]]]
        routes[min_k].insert(min_pos, i[c[0]])
    reroutes_time = []
    min_k_list = []
    for value in dict_ci.values():
        min_k_list.append(value[0])
    min_k_list = list(set(min_k_list))
    is_over = 0
    for k in min_k_list:
        if time_calculate(routes[k]) <= Tmax:
            reroutes_time.append(time_calculate(routes_cons[k]) - time_calculate(routes[k]))
        else:
            is_over = 1
    if sum(reroutes_time) > 0 and is_over == 0:
        return routes,sum(reroutes_time)
    else:
        return routes_cons,0

###############################################################
# LS operator 3-1
###############################################################
def relocate_move2(i, c, routes_cons):
    routes = copy.deepcopy(routes_cons)

    list_ci = regret_value_calculate([c], routes)
    dict_ci = min_k_pos_calculate(list_ci, [c])
    min_k = dict_ci[c][0]
    min_pos = dict_ci[c][1]
    routes[min_k].insert(min_pos, c)
    if time_calculate(routes[min_k]) <= Tmax:
        return routes
    else:
        return routes_cons

###############################################################
# LS operator 3-2
###############################################################
def exchange_move2(i, c, routes_cons):
    routes = copy.deepcopy(routes_cons)
    a, b = subscript_2D(i, routes)
    del routes[a][b]
    routes[a].insert(b, c)
    now_j = routes[a][b]
    be_i = routes_cons[a][b]
    if time_calculate(routes[a]) <= Tmax:
        temp_route_remove_be_i=copy.deepcopy(routes_cons[a])
        temp_route_remove_be_i.remove(be_i)
        if (time_calculate(routes_cons[a])-time_calculate(temp_route_remove_be_i)) == 0:
            before_ratio = float("inf")
        else:
            before_ratio = fitness_calculate([routes_cons[a]]) / (
                        time_calculate(routes_cons[a])-time_calculate(temp_route_remove_be_i))  
        temp_route_remove_now_j = copy.deepcopy(routes[a])
        temp_route_remove_now_j.remove(now_j)
        if (time_calculate(routes[a])-time_calculate(temp_route_remove_now_j)) == 0:
            after_ratio = float("inf")
        else:
            after_ratio = fitness_calculate([routes[a]]) / (
                        time_calculate(routes[a])-time_calculate(temp_route_remove_now_j))  
        if before_ratio < after_ratio:
            return routes
        else:
            return routes_cons
    else:
        return routes_cons

###############################################################
# local search
###############################################################
def LS(default_routes):
    times = 400
    active_list = [i for item in default_routes for i in item]
    routes = copy.deepcopy(default_routes)
    temp_best = copy.deepcopy(routes)
    while (times):
        random.shuffle(active_list)
        aux = []
        for i in active_list:
            for c in arc_nearcandi[i]:
                num = judge_relative_pos(i, c, routes)
                if num == 0:
                    k1, k2 = subscript_2D(i, routes)
                    incumbent = copy.deepcopy(routes)
                    incumbent[k1] = opt2(i, c, routes[k1])
                if num == 1:
                    temp_exchange, delta_increase_ex= exchange_move(i, c, routes)
                    temp_relocation, delta_increase_re = relocate_move([i, c], routes)
                    if delta_increase_ex > delta_increase_re:
                        incumbent=temp_exchange
                    if delta_increase_ex <= delta_increase_re :
                        incumbent=temp_relocation
                if num == 2:
                    if bidirect[c] not in [ii for item in routes for ii in item]:
                        relocation_sol = relocate_move2(i, c, routes)  
                        if fitness_calculate(relocation_sol) > fitness_calculate(routes):
                            incumbent = relocation_sol
                        else:
                            incumbent = exchange_move2(i, c, routes)
                    else:
                        incumbent = copy.deepcopy(routes)

                if fitness_calculate(incumbent) > fitness_calculate(routes):
                    if subscript_2D(c, incumbent) != []:
                        temp_routes_dummy = add_dummynode(routes)
                        temp_incumbent_dummy = add_dummynode(incumbent)
                        i1, i2 = subscript_2D(i, temp_routes_dummy)
                        j1, j2 = subscript_2D(c, temp_incumbent_dummy)
                        i_forward = temp_routes_dummy[i1][i2 - 1]
                        i_backward = temp_routes_dummy[i1][(i2 + 1) % len(temp_routes_dummy[i1])]
                        j_forward = temp_incumbent_dummy[j1][j2 - 1]
                        j_backward = temp_incumbent_dummy[j1][(j2 + 1) % len(temp_incumbent_dummy[j1])]
                        aux.append([i, c, i_forward, i_backward, j_forward, j_backward])
                    else:
                        temp_routes_dummy = add_dummynode(routes)
                        i1, i2 = subscript_2D(i, temp_routes_dummy)
                        i_forward = temp_routes_dummy[i1][i2 - 1]
                        i_backward = temp_routes_dummy[i1][i2 + 1 % len(temp_routes_dummy[i1])]
                        aux.append([i, c, i_forward, i_backward])
                if fitness_calculate(incumbent) > fitness_calculate(temp_best):
                    temp_best = copy.deepcopy(incumbent)
        if aux == []:
            break
        routes = copy.deepcopy(temp_best)
        flat_routes = [r for item in routes for r in item]
        aux = [au for item in aux for au in item]
        aux = list(set(aux))
        aux = [auu for auu in aux if auu in flat_routes and auu != (1, 1)]
        list(set(flat_routes))
        active_list = aux
    return temp_best

###############################################################
# perturbation operator 1
###############################################################
def remove_insert(routes):
    y1 = random.randint(5, 15) 
    removed_routes = copy.deepcopy(routes)
    oned = [i for item in removed_routes for i in item]#
    removed_arcs = [] 
    for re in range(y1):
        if len(oned) < 2: 
            break
        a = random.choice(oned)
        x, y = subscript_2D(a, removed_routes)
        if len(removed_routes[x]) >= 2:
            l = removed_routes[x][y]
            removed_arcs.append(a)
            removed_routes[x].remove(removed_routes[x][y])
            oned.remove(a)
    ####
    # regret value for removed_arcs
    ####
    list_ci = regret_value_calculate(removed_arcs, removed_routes) 
    delta_ci = delta_ci_calculate(list_ci)  
    ci_sort = []
    for index, item in enumerate(delta_ci):
        ci_sort.append((index, item))
    ci_sort_after = sorted(ci_sort, key=lambda x: x[1], reverse=True) 
    dict_ci = min_k_pos_calculate(list_ci, removed_arcs)  

    for c in ci_sort_after:  
        min_k, min_pos = dict_ci[removed_arcs[c[0]]]
        removed_routes[min_k].insert(min_pos, removed_arcs[c[0]])

    reroutes_time = []  
    min_k_list = []
    for value in dict_ci.values():
        min_k_list.append(value[0])
    min_k_list = list(set(min_k_list))
    is_over = 0
    for k in min_k_list:  
        if time_calculate(removed_routes[k]) <= Tmax: 
            reroutes_time.append(time_calculate(routes[k]) - time_calculate(removed_routes[k]))
        else:
            is_over = 1

    if sum(reroutes_time) >= 0 and is_over == 0:
        return removed_routes
    else:
        return routes

###############################################################
# perturbation operator 2
###############################################################
def exchange_based(reRoutes):
    routes = copy.deepcopy(reRoutes)
    y2 = random.randint(5, 15)
    for i in range(y2):
        temp_routes = copy.deepcopy(routes)
        while (1):
            index1 = random.randint(0, len(routes) - 1) 
            index2 = random.randint(0, len(routes) - 1) 
            if index1 != index2:
                break
        pos1_in_path1 = random.randint(0, len(routes[index1]) - 1)  
        pos2_in_path2 = random.randint(0, len(routes[index2]) - 1)
        routes[index1] = temp_routes[index1][:pos1_in_path1] + temp_routes[index2][pos2_in_path2:pos2_in_path2 + 1] + temp_routes[
                                                                                                                    index1][
                                                                                                                pos1_in_path1 + 1:]
        routes[index2] = temp_routes[index2][:pos2_in_path2] + temp_routes[index1][pos1_in_path1:pos1_in_path1 + 1] + temp_routes[
                                                                                                                    index2][
                                                                                                                pos2_in_path2 + 1:]
    all_feasiable = 0
    for i in routes:
        if time_calculate(i) <= Tmax:
            all_feasiable += 1
    if all_feasiable == len(routes):
        return routes
    else:
        while (1):
            for index_r,route in enumerate(routes):
                if time_calculate(route) > Tmax:
                    each_delta_ci = []
                    for item in route:
                        routes_temp = copy.deepcopy(routes)
                        routes_temp[index_r].remove(item)
                        list_ci = regret_value_calculate([item], routes_temp)
                        delta_ci = delta_ci_calculate(list_ci)
                        each_delta_ci.append(delta_ci[0])
                    routes[index_r].pop(each_delta_ci.index(min(each_delta_ci)))
            all_feasiable = 0
            for i in routes:
                if time_calculate(i) <= Tmax:
                    all_feasiable += 1
            if all_feasiable == len(routes):
                return routes

###############################################################
# perturbation function
###############################################################
def perturbation(routes):
    routes = remove_insert(routes)
    pertur_routes = exchange_based(routes)
    pertur_routes_flatten = [p for item in pertur_routes for p in item]
    y3 = random.randint(0, len(pertur_routes_flatten) )
    for j in range(y3):
        bi_routes = bidirect_insert(pertur_routes_flatten[j], pertur_routes)
        pertur_routes = bi_routes
    return pertur_routes

###############################################################
# iterated local search
###############################################################
def ILS():
    intial = initialize()
    incumbent = LS(intial)
    bestsol=copy.deepcopy(incumbent)
    iter_num = 150
    ci = 0.1
    while (iter_num > 0):
        s = perturbation(incumbent)
        s = LS(s)
        if fitness_calculate(s) >= fitness_calculate(bestsol):
            bestsol = s
        cigma = random.random()
        if fitness_calculate(s) >= fitness_calculate(bestsol):
            incumbent = s
        else:
            if math.exp(
                    (fitness_calculate(s) - fitness_calculate(bestsol)) / (ci * fitness_calculate(bestsol))) >= cigma:
                incumbent = s
            else:
                incumbent = bestsol
        iter_num -= 1
    objective=fitness_calculate(bestsol)
    print(objective)
    return bestsol,objective

def candidate_list_calculate(profit_arcs, routes):
    routes_flat = routes
    arc_nearcandi = defaultdict(list)
    for r in routes_flat:
        candidate_list = []
        for p in profit_arcs:
            shortest_dist,_,_=dist_two_arcs(r, p)
            if r != p and shortest_dist < Near_max:
                candidate_list.append(p)
        arc_nearcandi[(r[0], r[1])] = candidate_list
    return arc_nearcandi

def dist_two_arcs(arc1,arc2):
    OD1= [OD[arc1[1]][arc2[0]],0]
    OD2=[OD[arc1[1]][arc2[1]],1]
    OD3=[OD[arc1[0]][arc2[1]],2]
    OD4=[OD[arc1[0]][arc2[0]],3]
    OD_list=[OD1,OD2,OD3,OD4]
    res=sorted(OD_list)
    if res[0][1]==0:
        direct_arc1=(arc1[0],arc1[1])
        direct_arc2=(arc2[0],arc2[1])
    if res[0][1]==1:
        direct_arc1=(arc1[0],arc1[1])
        direct_arc2=(arc2[1],arc2[0])
    if res[0][1] == 2:
        direct_arc1 = (arc1[1], arc1[0])
        direct_arc2 = (arc2[1], arc2[0])
    if res[0][1] == 3:
        direct_arc1 = (arc1[1], arc1[0])
        direct_arc2 = (arc2[0], arc2[1])
    return res[0][0],direct_arc1,direct_arc2

def file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            if os.path.splitext(file)[1] == '.txt':
                L.append(file)
    return L

def fitness_calculate(routes):
    fit = 0
    for r in routes:
        if r==[]:
            return 0
    start_times, length_list = start_time_calculate(routes)
    for r in range(len(routes)):
        for a in range(len(routes[r])):
            profits_period = [(c, b) for (c, b) in profits_time if
                              c <= int(start_times[r][a + 1]) <= b]
            m=[profits_time[i] for i in profits_period]
            n = profits_p_Edges[routes[r][a]]
            p = [profits[j][n] for j in m]
            fit = fit +max(p) # profits[m][n]
    return fit

def start_time_calculate(routes):
    start_time_list = []
    length_list = []
    for r in routes:
        one_start_list = [0]
        one_path_length = []
        for no in range(len(r)):
            if no == 0:
                one_path_length.append(OD[depot[1]][r[no][0]] + dist[r[no]])
            else:
                one_path_length.append(OD[r[no - 1][1]][r[no][0]] + dist[r[no]])
            one_start_list.append(sum(one_path_length) - dist[r[no]])
        one_path_length.append(OD[r[len(r) - 1][1]][depot[0]])
        if r[len(r) - 1][1] != depot[0]:
            one_start_list.append(sum(one_path_length))
        start_time_list.append(one_start_list)
        length_list.append(sum(one_path_length))
    return start_time_list, length_list

def main():
    global p_Edges, OD, dist, profits, bidirect, profits_p_Edges, arc_nearcandi, start_nearcandi,profits_time,num_vehicles,Near_max,Tmax,cube_max
    # read data
    timelist=[30]
    instance_dir = r"C:\Users\89245\Desktop\DATA210331\\"
    instance = "network.txt"
    instance_profit_dir = r'C:\Users\89245\Desktop\210407TEST\sioux_6_rerandom\\'
    result_dir = r'C:\Users\89245\Desktop\210407TEST\ILS_Pypy_rerandom\\'
    instance_list = file_name(instance_profit_dir)
    for vehicle in range(2, 6):
        num_vehicles = vehicle
        for index,t in enumerate(timelist):
            Near_max=t
            Tmax=t
            cube_max=t
            for instance_profit in instance_list:
               if instance_profit=="sioux_25_6.txt":
                    average_obj=[]
                    for i_times in range(10):
                        p_Edges, bidirect, OD, dist, profits, profits_p_Edges,profits_time = load_INS(instance_dir, instance,
                                                                                         instance_profit_dir, instance_profit)
                        arc_nearcandi = candidate_list_calculate(p_Edges, p_Edges)
                        start_nearcandi = candidate_list_calculate(p_Edges, [depot])
                        start_time = time.time()
                        si, objective = ILS()                               # solve the problem by the ILS
                        fin_time = time.time()
                        delta_time = fin_time - start_time
                        print(delta_time)
                        average_obj .append(objective)
                        pa = result_dir + str(num_vehicles)+"_"+str(Tmax)+"_"+str(depot[0])+"_"+instance_profit
                        with open(pa, 'a') as file_object:                  # save the solutions
                            file_object.write(str("no.")+str(i_times)+":\n")
                            file_object.write(str(delta_time) + "\n")
                            file_object.write(str(objective) + "\n")
                            file_object.write(str(si) + "\n")
                            if i_times==9:
                                aver=sum(average_obj) / 10
                                maxi=max(average_obj)
                                file_object.write("average obj:"+str(aver)+"\n")
                                file_object.write("max obj:" + str(maxi) + "\n")
main()


