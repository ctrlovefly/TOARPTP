# python interpreter: python3.7
# Solve the classic TOARP-ST problem

import gurobipy as gp
from gurobipy import GRB
import re
import ast
from collections import defaultdict
import ODmatrix
import os
import read_func
import Djikstra

def model_solve(path,filename,path1,filename1,outpath):
    """
    path:path_instance
    filename:filename_instance
    path1:path_multiprofit
    filename1:filename_multiprofit
    outpath:write in the txt of the path
    """
    # read data from .txt files
    edges, cost = read_func.read_sioux(path, filename)
    p_edges, profit=read_func.read_profits_TOARP(path1,filename1)
    vehicle = range(num_vehicle)
    dist = defaultdict(list)
    for i, item in enumerate(edges):
        dist[item] = cost[i]
    demand = defaultdict(list)
    for i, item in enumerate(p_edges):
        demand[item] = profit[i]
    _, cost_enum = gp.multidict(dist)
    _, profit_enum = gp.multidict(demand)

    # some parameters
    Tmax = 30      # task period
    O = [(9,9)]    # depot
    M = 1000       # big M
    num_vertex=24  # number of the nodes in the Sioux Falls network

    # OD matrix
    OD_cal_list=[]
    for i,j in cost_enum:
        OD_cal_list.append((i,j,cost_enum[(i,j)]))
    OD=ODmatrix.OD_cal(OD_cal_list,num_vertex)

    # Gurobi modeling
    m = gp.Model("TOARP")

    # Variables
    yijk = m.addVars(p_edges, vehicle, vtype=GRB.BINARY, name="yijk")
    bij = m.addVars(p_edges,lb=0.0, vtype=GRB.CONTINUOUS, name="bij")
    union_p_edges=list(set(p_edges).union(set(O)))
    z = m.addVars(union_p_edges, union_p_edges, vehicle, vtype=GRB.BINARY, name="z")

    # Objective
    obj = gp.quicksum(profit_enum[e1, e2] * yijk[e1, e2, k] for e1, e2 in p_edges for k in vehicle)
    m.setObjective(obj, GRB.MAXIMIZE)

    # Constraints
    m.addConstrs((gp.quicksum(z[O[0][0],O[0][1],i,j,k] for i,j in p_edges)==1 for k in vehicle), "depot_left")

    m.addConstrs((gp.quicksum(z[i,j,O[0][0],O[0][1],k] for i,j in p_edges)==1 for k in vehicle), "depot_right")

    m.addConstrs((gp.quicksum(yijk[i,j,k] for k in vehicle)+gp.quicksum(yijk[j,i,k] for k in vehicle)<=1 for i,j in p_edges if (j,i) in p_edges),"only_once")

    m.addConstrs((gp.quicksum(yijk[i,j,k] for k in vehicle)<=1 for i,j in p_edges),"only_one_vehicle")

    m.addConstrs((gp.quicksum(z[i,j,i1,j1,k] for i1,j1 in union_p_edges)==gp.quicksum(z[i2,j2,i,j,k] for i2,j2 in union_p_edges) for k in vehicle for i,j in p_edges),"vrp_flow_conservation")

    m.addConstrs((gp.quicksum(z[i2,j2,i,j,k] for i2,j2 in union_p_edges)==yijk[i,j,k] for k in vehicle for i,j in p_edges),"relation between z and yijk")

    m.addConstrs((bij[i1,j1]+M*(1-gp.quicksum(z[i,j,i1,j1,k] for k in vehicle))>=bij[i,j]+cost_enum[i,j]+OD[j-1][i1-1] for i,j in p_edges for i1,j1 in p_edges),"start time ctrl")

    m.addConstrs((bij[i1,j1]-M*(1-gp.quicksum(z[i,j,i1,j1,k] for k in vehicle))<=bij[i,j]+cost_enum[i,j]+OD[j-1][i1-1] for i,j in p_edges for i1,j1 in p_edges),"start time ctrl2")

    m.addConstrs((gp.quicksum(OD[j-1][i1-1]*z[i,j,i1,j1,k] for i,j in union_p_edges for i1,j1 in union_p_edges)+gp.quicksum(cost_enum[i,j]*yijk[i,j,k]for i,j in p_edges)<=Tmax for k in vehicle),"totel time")

    m.addConstrs((bij[i,j]+M*(1-z[O[0][0],O[0][1],i,j,k])>=OD[O[0][0]-1][i-1] for i,j in p_edges for k in vehicle),"start time ctrl3")

    m.addConstrs((bij[i,j]-M*(1-z[O[0][0],O[0][1],i,j,k])<=OD[O[0][0]-1][i-1] for i,j in p_edges for k in vehicle),"start time ctrl4")

    m.addConstrs((bij[i,j]+cost_enum[i,j]+OD[j-1][O[0][0]-1]<=Tmax+M*(1-yijk[i,j,k]) for i,j in p_edges for k in vehicle),"start time ctrl5")

    # get solutions
    def getvars():
        xijkx_res=[]
        zijijk = m.getAttr('x', z)
        for k in vehicle:
            for i, j in union_p_edges:
                for i1,j1 in union_p_edges:
                    if z[i, j, i1, j1, k].x > 0:
                        xijkx_res.append([i,j,i1,j1,k])
        return xijkx_res

    edges_3D =[]
    for index,item in enumerate(edges):
        edges_3D.append((item[0],item[1],cost[index]))

    # extract routes from solutions
    def routes_cal(edges,res_zijijk):
        vehicle_num = set()
        for i in res_zijijk:
            vehicle_num.add(i[4])                         # i[num]: num changes with the number of the used UAVs
        routes=[]
        for i in range(len(vehicle_num)):
            route=[]
            current_start = O[0]
            route.append(current_start)
            time=0
            while(1):

                for index,item in enumerate(res_zijijk):
                    if item[4]==i and (item[0],item[1])==route[-1]:
                        _,list_piece=Djikstra.dijkstra(edges,item[1],item[2])
                        piece=[]
                        for j in range(len(list_piece)-1):
                            piece.append((list_piece[j],list_piece[j+1]))
                        route.extend(piece)
                        route.append((item[2],item[3]))
                        time+=1
                        break
                if route[-1] == O[0] and time > 0:
                    break
            route.pop(0)
            route.pop(-1)
            routes.append(route)
        return routes

    # write results in one .txt file
    def write_in():
        x_res = getvars()
        routes=routes_cal(edges_3D,x_res)
        pa = outpath + str(num_vehicle)+"_"+ "TOARP_"+filename1
        # filename = 'test_text.txt'
        with open(pa, 'w') as file_object:
            for r in routes:
                file_object.write(str(r)+"\n")
            file_object.write(str(m.Runtime) + "\n")
            file_object.write(str(m.objVal) + "\n")
            yijkx = m.getAttr('x', yijk)
            for k in vehicle:
                for i,j in p_edges:
                    if yijk[i,j,k].x > 0:
                        file_object.write("["+str(i)+","+str(j)+","+str(k)+"],\n")

    # set the solving time limit
    m.Params.timeLimit=10000
    # solve the model
    m.optimize()
    write_in()

def file_name(file_dir):
    L=[]
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            if os.path.splitext(file)[1] == '.txt':  # 想要保存的文件格式
                L.append(file)
    return L

if __name__ == '__main__':
    global num_vehicle
    instance_dir = r"C:\Users\89245\Desktop\DATA210331\\"                       # network file path
    instance="network.txt"                                                      # network file name
    instance_profit_dir=r'C:\Users\89245\Desktop\210407TEST\sioux_6\\'          # profit file path
    result_dir = r'C:\Users\89245\Desktop\210407TEST\guModel_TO\\'              # result file output path
    instance_list = file_name(instance_profit_dir)                              # read the file names of multiple profit files
    for instance_profit in instance_list:                                       # solve models with different profit inputs
        if instance_profit=="sioux_20_6.txt":
            for i in range(2,6):                                                # solve models with different UAV numbers
                num_vehicle=i
                model_solve(instance_dir, instance, instance_profit_dir, instance_profit, result_dir)
    print("finished!")



